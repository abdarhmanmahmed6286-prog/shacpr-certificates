import { getStore } from '@netlify/blobs';

const json = (body, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { 'content-type': 'application/json; charset=utf-8' }
});

export default async (request) => {
  if (request.method !== 'POST') return json({ error: 'Method not allowed' }, 405);

  try {
    const form = await request.formData();
    const file = form.get('file');
    const code = String(form.get('code') || '').trim().toLowerCase();
    if (!(file instanceof File) || file.type !== 'application/pdf' || !code) {
      return json({ error: 'A PDF file and certificate code are required' }, 400);
    }
    if (file.size > 10 * 1024 * 1024) {
      return json({ error: 'PDF file is too large' }, 413);
    }

    const store = getStore('certificate-pdfs');
    const key = `${code}.pdf`;
    await store.set(key, file, {
      metadata: { contentType: 'application/pdf', certificateCode: code }
    });

    const base = new URL(request.url).origin;
    return json({
      key,
      pdfUrl: `${base}/.netlify/functions/get-pdf?code=${encodeURIComponent(code)}`
    });
  } catch (error) {
    console.error(error);
    return json({ error: 'Unable to store PDF' }, 500);
  }
};
