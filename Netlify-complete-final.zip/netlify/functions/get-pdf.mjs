import { getStore } from '@netlify/blobs';

export default async (request) => {
  try {
    const code = String(new URL(request.url).searchParams.get('code') || '').trim().toLowerCase();
    if (!code) return new Response('Missing certificate code', { status: 400 });

    const store = getStore('certificate-pdfs');
    const file = await store.get(`${code}.pdf`, { type: 'arrayBuffer' });
    if (!file) return new Response('PDF not found', { status: 404 });

    return new Response(file, {
      headers: {
        'content-type': 'application/pdf',
        'cache-control': 'public, max-age=31536000, immutable'
      }
    });
  } catch (error) {
    console.error(error);
    return new Response('Unable to read PDF', { status: 500 });
  }
};
